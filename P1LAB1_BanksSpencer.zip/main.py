user_name = input()
print(f"Hello {user_name} and welcome to CS Online!")